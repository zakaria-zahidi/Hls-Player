<?php
$url_base = "https://localhost/"; //Your domain website
function base64url_encode($data)
{
	return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}
if (isset($_POST['url'])) {
	$codifica = base64url_encode(json_encode(array('url' => $_POST['url'], 'thumbnail' => $_POST['thumbnail'])));
	$linkCodificado = "$url_base/iframe.php?video=$codifica";
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
	<title>GN PLAYER | PLAYER GENERATE</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!--===============================================================================================-->
	<link rel="icon" type="image/png" href="images/icons/favicon.ico" />
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
	<script src="https://cdn.jsdelivr.net/clipboard.js/1.5.13/clipboard.min.js"></script>
	<script src="https://styplex.com/app/content/assets/js/init.js?52888"></script>

	<script src="https://styplex.com/app/content/assets/js/jquery/jquery.min.js"></script>
	<!--===============================================================================================-->
</head>

<body class="body">

	<div class="limiter" style="height: 60px !important;">
		<div class="container-login100" style="background-image: url('images/background.jpg');">
			<div class="wrap-login100 p-t-190 p-b-30">
				<div class="container">
					<span class="login100-form-title p-t-20 p-b-45">
						Okay, your player has been generated
						<br> <a href="<?= $linkCodificado ?>" style="color: white; text-weight: 900;"> Go player</a></span>

				</div>
			</div>
		</div>
	</div>




	<!--===============================================================================================-->
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
	<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
	<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
	<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body>

</html>