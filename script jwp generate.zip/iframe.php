<?php
function base64url_decode($data)
{
	return base64_decode(str_pad(strtr($data, '-_', '+/'), strlen($data) % 4, '=', STR_PAD_RIGHT));
}
if (isset($_GET['video'])) {

	$data = json_decode(base64url_decode($_GET['video']), true);


	$logo = "https://i.imgur.com/ewRMLz3.png"; // YOUR LOGO

	// $final = base64url_decode($_GET['dt']);


	$file = '[{"type": "video/mp4", "label": "HD", "file": "' . $data['url'] . '"}]';

?>

	<div id="player"></div>
	<script type="text/javascript" src="https://assets.nlm.nih.gov/jwplayer/8/jwplayer.js"></script>
	<script type="text/javascript">
		jwplayer.key = "eNFaXCjyURVoCCGiHp7HTQ3hDhE/AfL0g8VE1fRbL84=";
		var playerInstance = jwplayer("player");
		playerInstance.setup({
			sources: <?= $file ?>,
			image: "<?= $data['thumbnail'] ?>",
			autostart: false,
			controls: true,
			width: "100%",
			height: "100%",
			aspectratio: "16:9",
			abouttext: "<strong>YOUR TEXT</strong>",
			aboutlink: "YOUR LINK",


			<?php
			if (isset($logo)) {
			?>
				logo: {
					file: "<?= $logo ?>",
					position: 'top-left',
					margin: '10'
				},
			<?php
			}


			?>
		});
	</script>
	<style type="text/css">
		body {
			padding: 0;
			margin: 0;
			background: #000
		}

		.jwplayer.jw-flag-aspect-mode,
		.video-js {
			width: 100% !important;
			height: 100% !important
		}

		#player {
			text-align: center;
			color: #fff;
		}
	</style>
	<!--iklan pop up paste disini-->

<?php

} else {

?>


	<!DOCTYPE html>
	<html lang="en">

	<head>
		<title>GN PLAYER</title>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!--===============================================================================================-->
		<link rel="icon" type="image/png" href="images/icons/favicon.ico" />
		<!--===============================================================================================-->
		<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
		<!--===============================================================================================-->
		<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
		<!--===============================================================================================-->
		<link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
		<!--===============================================================================================-->
		<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
		<!--===============================================================================================-->
		<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
		<!--===============================================================================================-->
		<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
		<!--===============================================================================================-->
		<link rel="stylesheet" type="text/css" href="css/util.css">
		<link rel="stylesheet" type="text/css" href="css/main.css">
		<script src="https://cdn.jsdelivr.net/clipboard.js/1.5.13/clipboard.min.js"></script>
		<script src="https://styplex.com/app/content/assets/js/init.js?52888"></script>

		<script src="https://styplex.com/app/content/assets/js/jquery/jquery.min.js"></script>
		<!--===============================================================================================-->
	</head>

	<body class="body">

		<div class="limiter" style="height: 60px !important;">
			<div class="container-login100" style="background-image: url('images/background.jpg');">
				<div class="wrap-login100 p-t-190 p-b-30">
					<div class="container">
						<span class="login100-form-title p-t-20 p-b-45">
							Error @15579 - URL not defined!
							<br> By Souzx17
						</span>


					</div>
				</div>
			</div>
		</div>




		<!--===============================================================================================-->
		<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
		<!--===============================================================================================-->
		<script src="vendor/bootstrap/js/popper.js"></script>
		<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
		<!--===============================================================================================-->
		<script src="vendor/select2/select2.min.js"></script>
		<!--===============================================================================================-->
		<script src="js/main.js"></script>

	</body>

	</html>


<?php
}
